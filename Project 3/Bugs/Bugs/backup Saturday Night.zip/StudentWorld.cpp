#include "StudentWorld.h"
#include <string>
#include <map>
#include <set>
#include <iostream>


using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

// Students:  Add code to this file (if you wish), StudentWorld.h, Actor.h and Actor.cpp
int StudentWorld::init()
{
    Field f;
    string fieldFile = getFieldFilename();
    string error;
    if (f.loadField(fieldFile, error) != Field::LoadResult::load_success)
        {
        setError(fieldFile + " " + error);
        return GWSTATUS_LEVEL_ERROR;    // something bad happened!
        }
   
    
    //map<coord, set<Actor*>> m_map;
    
    for (double i = 0; i <VIEW_WIDTH; i++)
        for (double j = 0; j < VIEW_HEIGHT; j++)
        {
            m_corrdinate.emplace(i,j);
            Field::FieldItem item = f.getContentsOf(i, j);
            switch (item) {
                case Field::empty:
                    break;
                case Field::anthill0:
                {
                    Anthill* anthill0 = new Anthill(i,j);
                    set<Actor*> cur_square;
                    cur_square.insert(anthill0);
                    m_map[m_corrdinate] = cur_square;
                    break;
                }
                case Field::FieldItem::anthill1:
                {
                    Anthill* anthill1 = new Anthill(i,j);
                    set<Actor*> cur_square;
                    cur_square.insert(anthill1);
                    m_map[m_corrdinate] = cur_square;
                    break;
                }

                case Field::anthill2:
                {
                    Anthill* anthill2 = new Anthill(i,j);
                    set<Actor*> cur_square;
                    cur_square.insert(anthill2);
                    m_map[m_corrdinate] = cur_square;
                    break;
                }

                case Field::anthill3:
                {
                    Anthill* anthill3 = new Anthill(i,j);
                    set<Actor*> cur_square;
                    cur_square.insert(anthill3);
                    m_map[m_corrdinate] = cur_square;
                    break;
                }

                case Field::food:
                {
                    Food* food = new Food(i,j);
                    set<Actor*> cur_square;
                    cur_square.insert(food);
                    m_map[m_corrdinate] = cur_square;
                    break;
                }

                case Field::grasshopper:
                {
                    BabyGrasshopper* g = new BabyGrasshopper(i,j);
                    set<Actor*> cur_square;
                    cur_square.insert(g);
                    m_map[m_corrdinate] = cur_square;
                    break;
                }

                case Field::water:
                {
                    Water* w = new Water(i,j);
                    set<Actor*> cur_square;
                    cur_square.insert(w);
                    m_map[m_corrdinate] = cur_square;
                    break;
                }
                case Field::rock:
                {
                    Pebble* rock = new Pebble(i,j);
                    set<Actor*> cur_square;
                    cur_square.insert(rock);
                    m_map[m_corrdinate] = cur_square;
                    break;
                }
                case Field::poison:
                {
                    Poison* p = new Poison(i,j);
                    set<Actor*> cur_square;
                    cur_square.insert(p);
                    m_map[m_corrdinate] = cur_square;
                    break;
                }

                    
            }
        }
    
    m_tick = 0;
   
    updateTickCount();
    
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    m_tick++;
     updateTickCount();
    
    if(m_tick == 2000)
    {
        return GWSTATUS_NO_WINNER;
    }
    else
        return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    return;
}

void StudentWorld::updateTickCount()
{
    string text = "Ticks: ";
    string initial_ticks = to_string(m_tick);
    text += initial_ticks;
    text += " - ";
    vector<string> name = getFilenamesOfAntPrograms();
    
    setGameStatText(text);
}


