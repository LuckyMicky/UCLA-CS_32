#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include "Actor.h"
#include "Field.h"
#include <string>
#include <map>
#include <set>

using namespace std;


class Actor;                                        // ?????

typedef map<double,double> coord;
typedef set<Actor*> square;

//typedef map<coord, set<Actor*>> m_field;

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
	StudentWorld(std::string assetDir)
	 : GameWorld(assetDir)
	{
//        for (double i = 0; i <VIEW_WIDTH; i++)
//            for (double j = 0; j < VIEW_HEIGHT; j++)
//                m_corrdinate.emplace(i,j);
        
	}

    virtual int init();

        
		//return GWSTATUS_CONTINUE_GAME;
    virtual int move();
//	{
		  // This code is here merely to allow the game to build, run, and terminate after you hit enter.
		  // Notice that the return value GWSTATUS_NO_WINNER will cause our framework to end the simulation.
//		return GWSTATUS_NO_WINNER;
//	}

    virtual void cleanUp();
    
    void updateTickCount();
//	{
//	}
    
//    m_field getmap()
//    {
//        return m_map;
//    }

private:
    int m_tick;
    square m_map[VIEW_HEIGHT][VIEW_WIDTH];
//    coord m_corrdinate;
//    map<coord, square> m_map;
    
};

#endif // STUDENTWORLD_H_
